'use client'

import Link from 'next/link'
import './page-2.css'


type AuthorProfile = {
  name: string
  nim: string
  programStudi: string
  photoUrl: string | null
}

const author: AuthorProfile = {
  name: 'Maria Suhaila',
  nim: '2303020058',
  programStudi: 'Pendidikan Matematika',
  photoUrl: null,
}

const assets = {
  background:
    'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Background-AYVfyfZ2jrtRlPSmsDhD65flMPS5do.png',
  header:
    'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/fixed_header-R8NOtrcQNhvGZ32Db36AgdJcm2oZx2.png',
  classroom:
    'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/kids_and_teacher-4k6GLUhdp0BzqVRowUCxBPFL0ydEEk.png',
  scrollTextbox:
    'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/scroll-textbox-gqfIYRBPlL3oSRYoZa3ttQAcZW8F1c.png',
  forward:
    'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/forward-1FNPr3VFE6ZK7Tgdv0v8tnT5EasxcQ.png',
}

function AuthorPhoto({ photoUrl }: { photoUrl: string | null }) {
  if (photoUrl) {
    return <img className="author-photo" src={photoUrl} alt={`Foto ${author.name}`} />
  }

  return (
    <div className="author-photo author-photo-placeholder" role="img" aria-label="Tempat foto penyusun">
      <span aria-hidden="true">Foto</span>
      <small>penyusun</small>
    </div>
  )
}

function AuthorInfo({ profile }: { profile: AuthorProfile }) {
  return (
    <dl className="author-info">
      <div>
        <dt>Nama</dt>
        <dd>{profile.name}</dd>
      </div>
      <div>
        <dt>NIM</dt>
        <dd>{profile.nim}</dd>
      </div>
      <div>
        <dt>Program Studi</dt>
        <dd>{profile.programStudi}</dd>
      </div>
    </dl>
  )
}

export default function PageTwo() {
  return (
    <main className="page-shell author-page-shell">
      <section className="author-canvas" aria-label="Identitas penyusun">
        <img className="author-background" src={assets.background} alt="" />
        <img className="author-header" src={assets.header} alt="SMP Islam De Green Camp dan Kurikulum Merdeka" />
        <img className="author-classroom" src={assets.classroom} alt="" aria-hidden="true" />

        <h1 className="author-title">IDENTITAS PENYUSUN</h1>

        <section className="author-panel" aria-labelledby="author-panel-title">
          <img className="author-scroll" src={assets.scrollTextbox} alt="" aria-hidden="true" />
          <div className="author-panel-content">
            <h2 id="author-panel-title" className="sr-only">Identitas penyusun</h2>
            <AuthorPhoto photoUrl={author.photoUrl} />
            <AuthorInfo profile={author} />
          </div>
        </section>

        <Link className="forward-button" href="/page-3" aria-label="Lanjut ke halaman berikutnya">
          <img src={assets.forward} alt="Lanjut" />
        </Link>
      </section>
    </main>
  )
}

export type { AuthorProfile }
export { author }
