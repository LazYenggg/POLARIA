'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import './page-3.css'

function removeEdgeWhite(src: string) {
  return new Promise<string>((resolve) => {
    const image = new Image()
    image.crossOrigin = 'anonymous'
    image.onload = () => {
      const canvas = document.createElement('canvas')
      canvas.width = image.naturalWidth
      canvas.height = image.naturalHeight
      const context = canvas.getContext('2d', { willReadFrequently: true })
      if (!context) return resolve(src)
      context.drawImage(image, 0, 0)
      const pixels = context.getImageData(0, 0, canvas.width, canvas.height)
      const { data, width, height } = pixels
      const visited = new Uint8Array(width * height)
      const queue: number[] = []
      const isEdgeWhite = (point: number) => {
        const index = point * 4
        return data[index] > 242 && data[index + 1] > 242 && data[index + 2] > 242 && data[index + 3] > 0
      }
      const enqueue = (x: number, y: number) => {
        const point = y * width + x
        if (!visited[point] && isEdgeWhite(point)) {
          visited[point] = 1
          queue.push(point)
        }
      }
      for (let x = 0; x < width; x += 1) { enqueue(x, 0); enqueue(x, height - 1) }
      for (let y = 1; y < height - 1; y += 1) { enqueue(0, y); enqueue(width - 1, y) }
      for (let index = 0; index < queue.length; index += 1) {
        const point = queue[index]
        data[point * 4 + 3] = 0
        const x = point % width
        const y = Math.floor(point / width)
        if (x > 0) enqueue(x - 1, y)
        if (x < width - 1) enqueue(x + 1, y)
        if (y > 0) enqueue(x, y - 1)
        if (y < height - 1) enqueue(x, y + 1)
      }
      context.putImageData(pixels, 0, 0)
      resolve(canvas.toDataURL('image/png'))
    }
    image.onerror = () => resolve(src)
    image.src = src
  })
}

const assets = {
  background: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Background-AYVfyfZ2jrtRlPSmsDhD65flMPS5do.png',
  header: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/fixed_header-R8NOtrcQNhvGZ32Db36AgdJcm2oZx2.png',
  classroom: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/kids_and_teacher-4k6GLUhdp0BzqVRowUCxBPFL0ydEEk.png',
  textbox: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/scroll-textbox-gqfIYRBPlL3oSRYoZa3ttQAcZW8F1c.png',
  backward: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/backward_icon-V0I2FmyYTCT08HTIVFJHQW6DNSehWV.png',
  home: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/home_icon-cXYu3cywNAezOxlbp1bkBsbf7kYAZZ.png',
  forward: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/forward-1FNPr3VFE6ZK7Tgdv0v8tnT5EasxcQ.png',
}

const instructions = [
  <>1. Berdoalah sebelum mengerjakan</>,
  <>2. Tulis nama dan kelas dikolom identitas</>,
  <>3. Baca dan ikuti setiap langkah kegiatan<br />dengan teliti</>,
  <>4. Diskusikan jawaban bersama teman dan<br />guru</>,
  <>5. Tanyakan pada guru jika ada yang belum<br />dipahami</>,
]

const guideRows = [
  { key: 'backward', image: assets.backward, label: 'Kembali ke halaman sebelumnya', alt: 'Tombol kembali' },
  { key: 'home', image: assets.home, label: 'Kembali ke menu utama', alt: 'Tombol menu utama' },
  { key: 'forward', image: assets.forward, label: 'Lanjut ke halaman berikutnya', alt: 'Tombol lanjut' },
] as const

export default function PageThree() {
  const [processedAssets, setProcessedAssets] = useState(assets)

  useEffect(() => {
    let active = true
    Promise.all(Object.values(assets).map(removeEdgeWhite)).then(([background, header, classroom, textbox, backward, home, forward]) => {
      if (active) setProcessedAssets({ background, header, classroom, textbox, backward, home, forward })
    })
    return () => { active = false }
  }, [])

  return (
    <main className="page-shell guide-page-shell">
      <section className="guide-canvas" aria-label="Petunjuk penggunaan">
        <img className="guide-background" src={processedAssets.background} alt="" />
        <img className="guide-classroom" src={processedAssets.classroom} alt="" aria-hidden="true" />
        <img className="guide-header" src={processedAssets.header} alt="SMP Islam De Green Camp dan Kurikulum Merdeka" />

        <h1 className="guide-title">PETUNJUK PENGUNAAN</h1>
        <section className="guide-panel instructions-panel" aria-labelledby="instructions-title">
          <img src={processedAssets.textbox} alt="" aria-hidden="true" />
          <div className="panel-copy">
            <h2 id="instructions-title" className="sr-only">Petunjuk penggunaan</h2>
            {instructions.map((instruction, index) => <p key={index}>{instruction}</p>)}
          </div>
        </section>

        <h2 className="guide-title guide-title-secondary">PANDUAN TOMBOL</h2>
        <section className="guide-panel buttons-panel" aria-labelledby="buttons-title">
          <img src={processedAssets.textbox} alt="" aria-hidden="true" />
          <div className="panel-copy button-guide-copy">
            <h3 id="buttons-title" className="sr-only">Panduan tombol</h3>
            {guideRows.map((row) => (
              <div className="guide-row" key={row.key}>
                <span className="guide-icon-box"><img src={processedAssets[row.key]} alt={row.alt} /></span>
                <span>{row.label}</span>
              </div>
            ))}
          </div>
        </section>

        <nav className="guide-navigation" aria-label="Navigasi halaman">
          <Link href="/page-2" aria-label="Kembali ke halaman identitas penyusun">
            <img src={processedAssets.backward} alt="Kembali" />
          </Link>
          <Link href="/page-4" aria-label="Lanjut ke halaman berikutnya">
            <img src={processedAssets.forward} alt="Lanjut" />
          </Link>
        </nav>
      </section>
    </main>
  )
}
